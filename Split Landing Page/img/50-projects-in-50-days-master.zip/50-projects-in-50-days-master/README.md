# 50-projects-in-50-days

## Related Links  
Check out [the Course](https://www.udemy.com/course/50-projects-50-days/) & View **live demos** of all [Projects](https://50projects50days.com/)